package com.example.covitracker.repos

class RemoteRepository {
}
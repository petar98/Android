package com.example.covitracker.ui.adapters

class ModelListAdapter {
}
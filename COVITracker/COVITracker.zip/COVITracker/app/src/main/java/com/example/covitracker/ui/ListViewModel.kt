package com.example.covitracker.ui

class ListViewModel {
}
package com.example.covitracker.network.data

class GlobalData {
}
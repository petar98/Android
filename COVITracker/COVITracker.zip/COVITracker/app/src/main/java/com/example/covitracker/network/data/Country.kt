package com.example.covitracker.network.data

class Country {
}
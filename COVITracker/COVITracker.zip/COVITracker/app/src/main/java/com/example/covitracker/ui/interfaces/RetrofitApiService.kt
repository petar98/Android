package com.example.covitracker.ui.interfaces

interface RetrofitApiService {
}